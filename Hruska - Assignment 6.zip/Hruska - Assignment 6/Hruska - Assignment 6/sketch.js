var mX = [];
var mY = [];
var l;
var c = 20;

function setup() {
  createCanvas(400, 400);
  frameRate(60);
}

function draw() {
  yellow = color(230,230,0);
  darkOrange = color(230,130,0);
  lightOrange = color(230,150,0);
  darkBlue = color(0,0,100);
  darkRed = color(200,0,0);
  brown = color(90,40,10);
  
  background(darkBlue);
  
  strokeWeight(10);
  noStroke();
  fill(darkRed);
  circle(40,40,40);
  
  stroke(darkOrange);
  fill(lightOrange);
  
  ellipseMode(CENTER);
  ellipse(200, 230, 320, 320);
  ellipse(200, 230, 240, 320);
  ellipse(200, 230, 140, 320);
  ellipse(200, 230, 0, 320);
  
  noStroke();
  fill(brown);
  quad(195,70,205,70,205,60,195,55);
  
  stroke(yellow);
  strokeWeight(c);
  
  if (mouseIsPressed === true && dist(mouseX,mouseY,200,230) < 140) {
    l = mX.length;
    mX[l] = mouseX;
    mY[l] = mouseY;
  }
  
  for (i=0;i<mX.length;i++) {
    if (dist(mX[i],mY[i],mX[i-1],mY[i-1]) < 30) {
      if (i === 0) {
        point(mX[i],mY[i]);
      } else {
        line(mX[i],mY[i],mX[i-1],mY[i-1]);
      }
    }
  }
  
  print(mX.length);
}

function mousePressed(){
  if (dist(mouseX,mouseY,40,40) < 22) {
    mX = [];
    mY = [];
  }
}