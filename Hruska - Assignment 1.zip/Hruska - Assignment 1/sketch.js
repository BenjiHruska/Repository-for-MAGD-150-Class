function setup() {
  createCanvas(200, 200);
}

function draw() {

  background(20);  
  stroke(255);
    strokeWeight(2);
    point(14,22);
    point(37,125);
    point(63,95);
    point(42,75);
    point(56,36);
    point(177,63);
    point(84,58);
    point(140,86);
    point(167,111);
    point(20,176);
    point(147,16);
  
    strokeWeight(3);
    point(55,10);
    point(18,83);
    point(174,33);
    point(111,130);
    point(182,184);
  
    strokeWeight(4);
    point(44,153);
    point(96,102);
    point(150,143);
  
    strokeJoin(BEVEL);
    rect(5,5,190,190);
  
    strokeWeight(35);
    rotate(0);
    point(100,165);
  
    strokeWeight(50);
    point(120,40);
  
    noFill()
    strokeWeight(2);
    rotate(-30);
    ellipse(180,-73,10,80);
  
    strokeWeight(3);
    rotate(2);
    ellipse(-127,-7,90,20);
}