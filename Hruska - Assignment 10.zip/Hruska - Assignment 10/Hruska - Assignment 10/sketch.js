// Color Variables Defined
var skyBlue;
var oceanBlue;
var orng;
var pink;
var yelw;
var brwn;

function setup() {
    createCanvas(600, 400);
    noStroke();
    noLoop();
    rectMode(CORNERS);

    // Color Variables Specified
    skyBlue = color(180, 120, 90);
    oceanBlue = color(90, 140, 140);
    orng = color(255,185,80);
    red = color(255,125,80);
    yelw = color(255, 220, 80);
    brwn = color(90,65,45);
    whte = color(255,255,255);

    // Sunset : Radial
    fillGradient('radial', {
        from: [400, 156, 0],
        to:[400,156,400],
        steps: [
            [yelw,0],
            [orng,0.25],
            [red,1]
        ]
    });
    rect(0, 0, 600, 400);

    // Water Horizon : Linear
    fillGradient('linear', {
        from: [0, 244],
        to: [0, 400],
        steps: [
            [skyBlue,0.05],
            [oceanBlue,1]
        ]
    });
    rect(0, 256, 600, 400);

    // Ship
    fill(brwn);
    rect(140,190,160,310);
    arc(150,310,150,50,0,PI);

    // Sail: Conic
    fillGradient('conic', {
        from : [200, 200, 270],
        steps : [
            [whte,0],
            [orng,0.25],
            [whte,1]
        ]
    });
    rect(100,200,200,300);
}